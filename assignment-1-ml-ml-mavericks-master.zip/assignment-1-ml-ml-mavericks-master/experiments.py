import pandas as pd
import numpy as np
import time
import matplotlib.pyplot as plt
from tree.base import DecisionTree
from metrics import *

np.random.seed(42)
num_average_time = 10 # Number of times to run each experiment to calculate the average values

# Function to create fake data for different cases
def generate_fake_data(N, M, case):
    if case == "real_input_discrete_output":
        X = np.random.rand(N, M)
        y = np.random.randint(0, 2, size=N)
    elif case == "real_input_real_output":
        X = np.random.rand(N, M)
        y = np.random.rand(N)
    elif case == "categorical_input_discrete_output":
        X = np.random.randint(0, 2, size=(N, M))
        y = np.random.randint(0, 2, size=N)
    elif case == "categorical_input_real_output":
        X = np.random.randint(0, 2, size=(N, M))
        y = np.random.rand(N)
    else:
        raise ValueError("Invalid case")
    X = pd.DataFrame(X)
    y = pd.Series(y)
    return X, y

# Function to calculate average time for fit() and predict()
def calculate_average_time(model, X, y, num_average_time, N, M, case):
    fit_times = []
    predict_times = []

    for _ in range(num_average_time):
        start_time = time.time()
        model.fit(X, y)
        fit_times.append(time.time() - start_time)

        X_test = generate_fake_data(N // 2, M, case)[0]
        X_test = pd.DataFrame(X_test)
        start_time = time.time()
        _ = model.predict(X_test)
        predict_times.append(time.time() - start_time)

    avg_fit_time = np.mean(fit_times)
    avg_predict_time = np.mean(predict_times)
    return avg_fit_time, avg_predict_time

# Function to run experiments, learn decision trees, and show results/plots
def run_experiments(N_values, M_values, cases):
    fit_times = {case: [] for case in cases}
    predict_times = {case: [] for case in cases}
    for case in cases:
        print(f"********** {case.upper()} **********")
        for N in N_values:
            for M in M_values:
                X, y = generate_fake_data(N, M, case)

                # Decision Tree
                model = DecisionTree("information_gain")  
                avg_fit_time, avg_predict_time = calculate_average_time(model, X, y, num_average_time,N,M,case)

                fit_times[case].append(avg_fit_time)
                predict_times[case].append(avg_predict_time)
                print(f"N={N}, M={M}, Avg Fit Time: {avg_fit_time:.6f} seconds, Avg Predict Time: {avg_predict_time:.10f} seconds")
    return fit_times, predict_times
# Function to plot the results
def plot_results(N_values, M_values, fit_times, predict_times, cases):
    plt.figure(figsize=(12, 8))

    for case in cases:
        fit_times_case = fit_times[case]
        predict_times_case = predict_times[case]

        plt.subplot(2, 1, 1)
        for i in range(3):
            plt.plot(M_values, fit_times_case[(3*i):(3*(i+1))], label=f"N={N_values[i]}")
        plt.title(f'{case.capitalize()} - Average Fit Time vs. Number of Features')
        plt.xlabel('Number of Features (M)')
        plt.ylabel('Average Fit Time (seconds)')
        plt.legend()

        plt.subplot(2, 1, 2)
        for i in range(3):
            plt.plot(M_values, predict_times_case[(3*i):(3*(i+1))], label=f"N={N_values[i]}")
        plt.title(f'{case.capitalize()} - Average Predict Time vs. Number of Features')
        plt.xlabel('Number of Features (M)')
        plt.ylabel('Average Predict Time (seconds)')
        plt.legend()

    plt.tight_layout()
    plt.show()

# Define N and M values to experiment with
N_values = [15, 30, 60]
M_values = [2, 4, 8]
cases = ["real_input_discrete_output", "real_input_real_output", "categorical_input_discrete_output", "categorical_input_real_output"]

# Run experiments and collect fit_times and predict_times
fit_times, predict_times = run_experiments(N_values, M_values, cases)

# Plot the results
plot_results(N_values, M_values, fit_times, predict_times, cases)
