# Question 4 Explanation

Let  N = number of training examples,
     k = number of features, 
     and  d = depth of the decision tree.

A decision tree would calculate a quality function based on each split of the data, and it does this for each feature in every node that is not a leaf node. This happens as long as there are levels (depth) to continue to. In the best case of a balanced tree the depth would be in  O(logN)
 , but the decision tree does locally optimal splits without caring much about balancing. This means that the worst case of depth being in  O(N)
  is possible - basically when each split simply splits data in 1 and n-1 examples, where n is the number of examples of the current node.

So to conclude, the time complexity for decision trees is in O(Nkd)
 . This means that it’s actually somewhere in between being in  O(NklogN)
  and  O(N2k)

For Prediction, as we traverse the tree, we move one depth at each step. Therfore our time complexity will be directly proportional to the depth of the tree (O(d)). 

In Our Decision Tree we have got the following times for different values of M and N:

********** REAL_INPUT_DISCRETE_OUTPUT **********

N=15, M=2, Avg Fit Time: 0.551078 seconds, Avg Predict Time: 0.0015687466 seconds\
N=15, M=4, Avg Fit Time: 1.310071 seconds, Avg Predict Time: 0.0006555557 seconds\
N=15, M=8, Avg Fit Time: 2.340832 seconds, Avg Predict Time: 0.0000000000 seconds\
N=30, M=2, Avg Fit Time: 1.976513 seconds, Avg Predict Time: 0.0015623331 seconds\
N=30, M=4, Avg Fit Time: 2.961542 seconds, Avg Predict Time: 0.0064981461 seconds\
N=30, M=8, Avg Fit Time: 5.679950 seconds, Avg Predict Time: 0.0015625238 seconds\
N=60, M=2, Avg Fit Time: 4.278635 seconds, Avg Predict Time: 0.0039383411 seconds\
N=60, M=4, Avg Fit Time: 7.763958 seconds, Avg Predict Time: 0.0031332970 seconds\
N=60, M=8, Avg Fit Time: 15.781210 seconds, Avg Predict Time: 0.0031867504 seconds

********** REAL_INPUT_REAL_OUTPUT **********

N=15, M=2, Avg Fit Time: 0.634378 seconds, Avg Predict Time: 0.0031310797 seconds\
N=15, M=4, Avg Fit Time: 1.312353 seconds, Avg Predict Time: 0.0015627146 seconds\
N=15, M=8, Avg Fit Time: 2.364225 seconds, Avg Predict Time: 0.0000000000 seconds\
N=30, M=2, Avg Fit Time: 1.522696 seconds, Avg Predict Time: 0.0014357090 seconds\
N=30, M=4, Avg Fit Time: 2.838750 seconds, Avg Predict Time: 0.0015683174 seconds\
N=30, M=8, Avg Fit Time: 5.967297 seconds, Avg Predict Time: 0.0031251192 seconds\
N=60, M=2, Avg Fit Time: 3.174225 seconds, Avg Predict Time: 0.0023161411 seconds\
N=60, M=4, Avg Fit Time: 6.632357 seconds, Avg Predict Time: 0.0037701368 seconds\
N=60, M=8, Avg Fit Time: 12.664953 seconds, Avg Predict Time: 0.0033118248 seconds

********** CATEGORICAL_INPUT_DISCRETE_OUTPUT **********

N=15, M=2, Avg Fit Time: 0.024588 seconds, Avg Predict Time: 0.0008555889 seconds\
N=15, M=4, Avg Fit Time: 0.069643 seconds, Avg Predict Time: 0.0003484011 seconds\
N=15, M=8, Avg Fit Time: 0.124231 seconds, Avg Predict Time: 0.0015625238 seconds\
N=30, M=2, Avg Fit Time: 0.026205 seconds, Avg Predict Time: 0.0013722420 seconds\
N=30, M=4, Avg Fit Time: 0.101949 seconds, Avg Predict Time: 0.0031763792 seconds\
N=30, M=8, Avg Fit Time: 0.270817 seconds, Avg Predict Time: 0.0028312683 seconds\
N=60, M=2, Avg Fit Time: 0.027959 seconds, Avg Predict Time: 0.0005073309 seconds\
N=60, M=4, Avg Fit Time: 0.125629 seconds, Avg Predict Time: 0.0061354160 seconds\
N=60, M=8, Avg Fit Time: 0.418742 seconds, Avg Predict Time: 0.0080662966 seconds

********** CATEGORICAL_INPUT_REAL_OUTPUT **********

N=15, M=2, Avg Fit Time: 0.017638 seconds, Avg Predict Time: 0.0004590988 seconds\
N=15, M=4, Avg Fit Time: 0.069044 seconds, Avg Predict Time: 0.0004533768 seconds\
N=15, M=8, Avg Fit Time: 0.162985 seconds, Avg Predict Time: 0.0000000000 seconds\
N=30, M=2, Avg Fit Time: 0.018095 seconds, Avg Predict Time: 0.0018072605 seconds\
N=30, M=4, Avg Fit Time: 0.073832 seconds, Avg Predict Time: 0.0011313200 seconds\
N=30, M=8, Avg Fit Time: 0.262430 seconds, Avg Predict Time: 0.0015626192 seconds\
N=60, M=2, Avg Fit Time: 0.018302 seconds, Avg Predict Time: 0.0009450674 seconds\
N=60, M=4, Avg Fit Time: 0.089945 seconds, Avg Predict Time: 0.0016033888 seconds\
N=60, M=8, Avg Fit Time: 0.324657 seconds, Avg Predict Time: 0.0015623569 seconds

From these results, we observe that with increase in number of samples or number of attributes/features, the times for fit function are increasing almost linearly. 
These times are for a fixed depth of 5.

This indicates there is a linear dependence on the number of samples or number of attributes/features. Thus we can say that the time complexity can be O(NM).
As we have kept the depth same, there may have been a function of depth as well.

For the predict function we observe a constant relation, as it depends on the depth of the decision tree. Thus the time complexity will be O(1) that is a constant dependency in case of constant depth.

![image](https://github.com/ES335-2024/assignment-1-ml-ml-mavericks/assets/146793425/35114af6-cf67-4fc3-813a-a78bc58a16aa)
