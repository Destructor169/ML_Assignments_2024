"""
You can add your own functions here according to your decision tree implementation.
There is no restriction on following the below template, these fucntions are here to simply help you.
"""
import numpy as np
import pandas as pd
from pandas.core.common import flatten

def mse(y):
    m=y.mean()
    ms=((y-m)**2).mean()
    return ms

def info_gain_real(y):# y is a list containing pandas series

    n=len(y)# Total No. of Series in y
    total_ele=[]# Its an array containing all the elements, NOT YET FLATTENED

    for i in y:# Iterating through every pandas series in y
      ele=i.values# Getting a list of all the values of the pandas series
      total_ele.append(ele)# Appnding all the lists of elements in the list containing all elements.
    # Now, we need to flatten total_ele--> Find the Mean Squared Error

    total_ele=list(flatten(total_ele))# This is the FLATTENED list, containing all the elements.

    initial_mean=np.mean(total_ele)# Mean of all the elements
    init_mse=np.mean((total_ele-initial_mean)**2)# Mean squared error of all the elements taken together.

    num_total_ele=np.shape(total_ele)[0]# Total Number of elements in all the series
    # Now, calculate the weighted mean squared error of each of these sub-series.

    entropy_real=0


    for i in y:
      ele=i.values# List of all elements
      ele=np.array(ele)
      mean=np.mean(ele)# Mean of that list of elements
      mse=np.mean((ele-mean)**2)# Mean squared error of those list of elements
      weight=ele.shape[0]/num_total_ele# Weightage
      entropy_real+=weight*mse# Weighted Entropy of each pandas series in y

    info_real=init_mse-entropy_real# Subtract the weighted mse(s) from the total mse
    return(info_real)

# Split function
def split(X: pd.DataFrame, y: pd.Series, attribute, value):
  dataset1 = X.where(X[attribute] <= value).dropna()
  dataset2 = X.where(X[attribute] > value).dropna()

  y1=y[dataset1.index]
  y2=y[dataset2.index]

  return (dataset1,y1),(dataset2,y2)


# Best split
def best_split(X: pd.DataFrame, y: pd.Series,P:int , N:int, b1, criterion):
  best_split_info={}
  max_info_gain = -np.inf
  for i in range(P):

    attribute = X[X.columns[i]]

    threshhold= np.unique(attribute)
    mean_threshhold=[]

    for k in range(N-1):
      mean_threshhold.append(attribute.iloc[k:k+2].mean())

    for j in mean_threshhold:
      (dataset1,y1),(dataset2,y2) = split(X,y,X.columns[i],j)
      if b1:
        info_gain = info_gain_real([y1,y2])
      else :
        if criterion=="information_gain":
          w1=len(y1)/len(y)
          w2=len(y2)/len(y)
          info_gain = entropy(y)-(entropy(y1)*w1+entropy(y2)*w2)  
        else:
          w1=len(y1)/len(y)
          w2=len(y2)/len(y)
          info_gain = gini(y)-(gini(y1)*w1+gini(y2)*w2)
      if info_gain >= max_info_gain:
        max_info_gain = info_gain
        best_split_info['attribute'] = X.columns[i]
        best_split_info['threshhold'] = j
        best_split_info['dataset1'] = dataset1
        best_split_info['dataset2'] = dataset2
  s=best_split_info['attribute']
  t=best_split_info['threshhold']

  return best_split_info['attribute'], best_split_info['threshhold']




def check_if_real(y: pd.Series, tolerance=1e-10) -> bool:

    unique_values = y.unique()

    for val in unique_values:
      if len(unique_values) / len(y) >= 0.2:
        if not np.isclose(val, round(val), atol=tolerance):
            return True  # indicating real output

    return False  # indicating discrete output



def gini(series):
    value_counts = series.value_counts(normalize=True)
    gini = 1-np.sum((value_counts * np.log2(value_counts+1e-6))**2)
    return gini


def information_gain_gini(df, Y: pd.Series, attribute) -> float:
    """
    Function to calculate the information gain
    """

    total_gini = gini(Y)
    weighted_gini=0
    # Calculate the weighted average entropy for the given attribute
    weighted_entropy = 0.0
    col = df[attribute] ## attribute is column index
    unique_values = col.unique()
    #print("values",unique_values)
    for value in unique_values:
        subset_Y = Y[df[attribute] == value]
        weight = len(subset_Y) / len(Y)
        #print(entropy(subset_Y))
        weighted_gini += weight * gini(subset_Y)

    # Information Gain is the reduction in entropy
    information_gain = total_gini - weighted_gini
    return information_gain

def entropy(series):
    value_counts = series.value_counts(normalize=True)
    entropy = -np.sum(value_counts * np.log2(value_counts+(10**(-5))))
    return entropy


def information_gain_entropy(df, Y: pd.Series, attribute,b1) -> float:
    """
    Function to calculate the information gain
    """
    if b1:
        total_entropy = mse(Y)
    else:
        total_entropy = entropy(Y)
        

    # Calculate the weighted average entropy for the given attribute
    weighted_entropy = 0.0
    col = df[attribute] ## attribute is column index
    unique_values = col.unique()
    #print("values",unique_values)
    for value in unique_values:
        subset_Y = Y[df[attribute] == value]
        weight = len(subset_Y) / len(Y)
        #print(entropy(subset_Y))
        if b1:
            weighted_entropy += weight * mse(subset_Y)
        else:
            weighted_entropy += weight * entropy(subset_Y)
            
    # Information Gain is the reduction in entropy
    information_gain = total_entropy - weighted_entropy
    return information_gain
