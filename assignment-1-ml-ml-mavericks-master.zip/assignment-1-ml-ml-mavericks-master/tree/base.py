"""
The current code given is for the Assignment 1.
You will be expected to use this to make trees for:
> discrete input, discrete output
> real input, real output
> real input, discrete output
> discrete input, real output
"""
from dataclasses import dataclass
from typing import Literal

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from tree.utils import *
np.random.seed(42)


class Real_discrete_node:
  def __init__(self):
    self.attribute = None
    self.threshhold = None
    self.left = None
    self.right = None
    self.label=None
    self.data=None
  def display_tree_text(self, c, level=0):
    indent = "  " * level
    if self.left is None:
      if c=="r":
        print(f"{indent}|NO - {self.label}")
        return
      else:
        print(f"{indent}|YES - {self.label}")
        return

    elif c=="r":
      print(f"{indent}|NO - (Data[{self.attribute}] <= {self.threshhold}) :")
    else:
      if level==0:
        print(f"(Data[{self.attribute}] <= {self.threshhold}) :")    
      else:
        print(f"{indent}|YES - (Data[{self.attribute}] <= {self.threshhold}) :")

    self.left.display_tree_text("l", level + 1)
    self.right.display_tree_text("r", level + 1)

class Node:
    def __init__(self, attribute=None, label=None):
        self.attribute = attribute
        self.label = label
        self.children = {}
    def display_tree(self, val, level=0):
        indent="    "*level
        # Print the current node
        if self.attribute is not None:
            print(indent + "|" + str(val) + ":  " + str(self.attribute)  +"=>")
        else:
            print(indent + "|" + str(val) + ":  " + " Prediction: " + str(self.label))

        # Recursively print the children nodes
        for child in self.children.keys():
            self.children[child].display_tree(child,level + 1)


class DecisionTree:
    criterion: Literal["information_gain", "gini_index"]
    max_depth: int

    def __init__(self, criterion, max_depth=5):
        self.criterion = criterion
        self.max_depth = max_depth
        self.depth = 0
        self.root = None
        self.b1=None
        self.b2=None
    def the_real_fit(self,node , X: pd.DataFrame, y:pd.Series)->None:
        if self.depth==0:
            self.b1=check_if_real(y)
            self.b2=check_if_real(X.iloc[:,1])
            
        if self.b2:
            root= node
            n,p = X.shape
            features = np.arange(p)


            if y.nunique() == 1:
                root.label = y.unique()[0]
                return

            if self.depth>=self.max_depth:
                if self.b1:
                    root.label = y.mean()
                else :
                    root.label = y.mode().iloc[0]
                return

            self.depth += 1

            root.attribute, root.threshhold = best_split(X, y, p, n, self.b1, self.criterion)

            root.left = Real_discrete_node()
            root.right = Real_discrete_node()
            (d1,root.left.data),(d2,root.right.data) = split(X, y, root.attribute, root.threshhold) #self.root.right.data = split(X, y, self.root.attribute, self.root.threshhold)
            if (self.depth==1):
                self.root=root

            self.the_real_fit(root.left,d1,root.left.data)
            self.the_real_fit(root.right,d2,root.right.data)
            self.depth-=1

        else:
            n,p = X.shape
            features = X.columns
            
            root = node

            if y.nunique() == 1 :   ## when the target value has only one possible value
                root.label = y.unique()[0]
                return

            if len(features) == 0 or self.depth == self.max_depth:
                if self.b1:
                    root.label = y.mean()
                else:
                    root.label = y.mode().iloc[0]
                return

            #print("here")
            self.depth += 1

            best_attribute = None
            best_info_gain = -np.inf
            for attribute in features:
                #print("here")
                if not self.b1:
                    if self.criterion=="gini_index":
                        info_gain = information_gain_gini(X,y,attribute)
                    else:
                        info_gain = information_gain_entropy(X, y,attribute,self.b1)
                else:
                    info_gain = information_gain_entropy(X, y,attribute,self.b1)
                #print("here")
                if info_gain > best_info_gain:
                    best_attribute = attribute
                    best_info_gain = info_gain

            root.attribute = best_attribute
            #print("here")
            features_values = X[root.attribute].unique()
            #print("here1")
            for val in features_values:
                #print("here1")
                child = Node()
                root.children[val] = child
                #print("here2")
                sub_X = X[X[root.attribute] == val] ##Possible split_data code
                sub_X = sub_X.drop(columns = root.attribute)
                #print("here2")
                sub_y = y[X[root.attribute] == val]
                if (self.depth==1):
                    self.root=root
                self.the_real_fit(child,sub_X, sub_y)

            self.depth -= 1

    def fit(self, X: pd.DataFrame, y:pd.Series)->None:
        if self.depth==0:
            self.b1=check_if_real(y)
            self.b2=check_if_real(X.iloc[:,1])
        if self.b2:
            node = Real_discrete_node()
        else:
            node = Node()
        self.the_real_fit(node,X,y)     
    def predict(self, X: pd.DataFrame) -> pd.Series:
            """
            Funtion to run the decision tree on test inputs
            """
            b1=self.b1
            b2=self.b2
            if (b2):
                y_pred=[]
                j=0
                for ind,i in X.iterrows():

                    node=self.root
                    while (node.label==None):

                        if i[node.attribute]<=node.threshhold :
                            node=node.left
                        else:
                            node=node.right
                    y_pred.append(node.label)
                    j+=1
                return pd.Series(y_pred)
                # Traverse the tree you constructed to return the predicted values for the given test inputs.
            else :
                

                predictions = []

                for _ , sample in X.iterrows():
                    current_node = self.root

                    n_iterations = 0
                    # Traverse the tree until a leaf node is reached
                    while current_node.children and n_iterations<100:
                        attribute_value = sample[current_node.attribute]
                        #print(attribute_value)

                        # Check if the attribute_value exists in the children of the current node
                        if attribute_value in current_node.children:
                            current_node = current_node.children[attribute_value]
                        # else:
                        #     # If the attribute_value is not found in the children, break the loop
                        #     print("Attribute Not found")
                        #     break
                        n_iterations+=1
                    # Append the label of the leaf node to the predictions
                    predictions.append(current_node.label)

                return pd.Series(predictions)
    def plot(self):
        if self.b2:
            self.root.display_tree_text("l")
        else:
            self.root.display_tree("")
