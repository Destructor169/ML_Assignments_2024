# Output 
The following is the output of the Testing on data generated:
```
Accuracy =>  0.8666666666666667
Precision (1):  0.9230769230769231
Recall (1):  0.8
Precision (0):  0.9230769230769231
Recall (0):  0.8
```
The following is the Output for 5 fold Cross validation :
```
Outer Fold 1, Inner Fold 1
Outer Fold 1, Inner Fold 2
Outer Fold 1, Inner Fold 3
Outer Fold 1, Inner Fold 4
Outer Fold 1, Inner Fold 5
Outer Fold 2, Inner Fold 1
Outer Fold 2, Inner Fold 2
Outer Fold 2, Inner Fold 3
Outer Fold 2, Inner Fold 4
Outer Fold 2, Inner Fold 5
Outer Fold 3, Inner Fold 1
Outer Fold 3, Inner Fold 2
Outer Fold 3, Inner Fold 3
Outer Fold 3, Inner Fold 4
Outer Fold 3, Inner Fold 5
Outer Fold 4, Inner Fold 1
Outer Fold 4, Inner Fold 2
Outer Fold 4, Inner Fold 3
Outer Fold 4, Inner Fold 4
Outer Fold 4, Inner Fold 5
Outer Fold 5, Inner Fold 1
Outer Fold 5, Inner Fold 2
Outer Fold 5, Inner Fold 3
Outer Fold 5, Inner Fold 4
Outer Fold 5, Inner Fold 5
     outer_fold  inner_fold  max_depth  val_accuracy
48          1.0         3.0        1.0        1.0000
83          2.0         3.0        6.0        1.0000
82          2.0         3.0        5.0        1.0000
49          1.0         3.0        2.0        1.0000
149         4.0         4.0        6.0        0.9375
..          ...         ...        ...           ...
0           0.0         0.0        1.0        0.8125
139         4.0         3.0        2.0        0.7500
138         4.0         3.0        1.0        0.7500
101         3.0         1.0        6.0        0.7500
100         3.0         1.0        5.0        0.7500

[150 rows x 4 columns]
max_depth
2.0    0.9075
1.0    0.8950
4.0    0.8925
3.0    0.8900
5.0    0.8825
6.0    0.8825
Name: val_accuracy, dtype: float64
```
We observe that our tree in this case has best accuracy at depth of 2 which is 0.9075 or 90.75%.
