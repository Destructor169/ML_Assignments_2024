# Output 
Following is the output recieved on running Usage.py

Note: In the question, it had been mentioned to use Gini Index as criterion for discrete inputs but not real inputs. Therefore we have removed the case for using Gini index for real outputs.

```
(Data[4] <= 0.2784337337408048) :
  |YES - (Data[3] <= 0.49907553795098697) :
    |YES - (Data[2] <= 1.03032756205547) :
      |YES - (Data[2] <= -0.5005302221716099) :
        |YES - (Data[1] <= 0.6878528645442277) :
          |YES - 0.4380060206085728
          |NO - -0.2550224746204133
        |NO - (Data[0] <= 0.78828567931571) :
          |YES - -0.6874981169421364
          |NO - -0.03827630603884363
      |NO - (Data[4] <= -1.2857668791279608) :
        |YES - 0.6565536086338297
        |NO - 0.82206015999449
    |NO - (Data[4] <= -0.7116126406075389) :
      |YES - (Data[4] <= -1.92530471026185) :
        |YES - 0.9633761292443218
        |NO - 1.4535340771573169
      |NO - (Data[4] <= -0.21325716975222925) :
        |YES - 0.25049285034587654
        |NO - -0.0771017094141042
  |NO - (Data[4] <= 1.003272324809155) :
    |YES - (Data[4] <= 0.4419208835167282) :
      |YES - 2.720169166589619
      |NO - (Data[0] <= -0.41792178458928875) :
        |YES - (Data[3] <= -1.1269587765182856) :
          |YES - 1.158595579007404
          |NO - 1.881283746899352
        |NO - (Data[4] <= 0.8637390799045667) :
          |YES - 0.3214303278812129
          |NO - 0.787084603742452
    |NO - -0.9746816702273214
Criteria : information_gain
RMSE:  0.28429211926321174
MAE:  0.14696789822891002
(Data[0] <= -0.29001883978341975) :
  |YES - (Data[1] <= 1.0923865481206994) :
    |YES - (Data[4] <= 2.9983377899900234) :
      |YES - (Data[2] <= -1.326475066792248) :
        |YES - 0
        |NO - (Data[4] <= -1.0710347428873037) :
          |YES - 0
          |NO - 1
      |NO - 4
    |NO - (Data[0] <= -0.8660086274155504) :
      |YES - 4
      |NO - 3
  |NO - (Data[4] <= 0.76601554186545) :
    |YES - (Data[3] <= 0.5560053852404514) :
      |YES - (Data[0] <= 0.9516883816646932) :
        |YES - (Data[4] <= -0.2937531246478271) :
          |YES - 1
          |NO - 4
        |NO - (Data[3] <= -0.35253532412019056) :
          |YES - 2
          |NO - 4
      |NO - (Data[2] <= 1.0185265033342397) :
        |YES - 2
        |NO - 1
    |NO - (Data[4] <= 1.7192560909052979) :
      |YES - (Data[4] <= 1.0789560709752766) :
        |YES - 3
        |NO - 4
      |NO - 0
Criteria : information_gain
Accuracy:  0.9333333333333333
Precision:  0.9
Recall:  0.9
Precision:  0.9
Recall:  0.9
Precision:  0.9
Recall:  0.9
Precision:  0.9
Recall:  0.9
Precision:  0.9
Recall:  0.9
(Data[4] <= 0.10383294157262118) :
  |YES - (Data[1] <= 0.8481750832744166) :
    |YES - (Data[4] <= -0.6834111239548556) :
      |YES - (Data[2] <= 0.17247153446074354) :
        |YES - (Data[4] <= -1.0744938396651627) :
          |YES - 1
          |NO - 2
        |NO - (Data[4] <= -1.0909025290518635) :
          |YES - 0
          |NO - 4
      |NO - (Data[4] <= -0.07552232416591637) :
        |YES - (Data[1] <= 0.023637300268943354) :
          |YES - 0
          |NO - 1
        |NO - (Data[4] <= 0.03048627271108721) :
          |YES - 1
          |NO - 4
    |NO - (Data[4] <= -0.8607813091939538) :
      |YES - 1
      |NO - (Data[4] <= -0.25873094853711986) :
        |YES - 2
        |NO - 4
  |NO - (Data[3] <= 0.8131858774197993) :
    |YES - (Data[4] <= 0.8135336941127804) :
      |YES - (Data[3] <= 0.18640881607098816) :
        |YES - (Data[4] <= 0.4051691631103836) :
          |YES - 1
          |NO - 2
        |NO - (Data[4] <= 0.628987175593946) :
          |YES - 4
          |NO - 1
      |NO - (Data[4] <= 1.4927333547262454) :
        |YES - 3
        |NO - (Data[4] <= 2.138488731990796) :
          |YES - 0
          |NO - 1
    |NO - (Data[4] <= 0.8312471465596882) :
      |YES - (Data[4] <= 0.38099859846300144) :
        |YES - 2
        |NO - 1
      |NO - 4
Criteria : gini_index
Accuracy:  0.7
Precision:  0.6153846153846154
Recall:  0.8
Precision:  0.6153846153846154
Recall:  0.8
Precision:  0.6153846153846154
Recall:  0.8
Precision:  0.6153846153846154
Recall:  0.8
Precision:  0.6153846153846154
Recall:  0.8
|:  1=>
    |3:  4=>
        |4:  0=>
            |0:   Prediction: 0
            |1:   Prediction: 2
            |3:   Prediction: 0
        |2:   Prediction: 2
        |0:   Prediction: 3
        |3:   Prediction: 3
    |0:  4=>
        |4:  0=>
            |3:   Prediction: 0
            |0:   Prediction: 4
        |1:  0=>
            |3:  2=>
                |4:  3=>
                    |0:   Prediction: 0
        |2:   Prediction: 4
        |0:   Prediction: 0
    |4:  0=>
        |4:   Prediction: 1
        |3:  2=>
            |1:   Prediction: 3
            |3:   Prediction: 1
        |2:   Prediction: 1
        |0:   Prediction: 3
    |1:  0=>
        |3:   Prediction: 2
        |1:   Prediction: 2
        |0:   Prediction: 3
    |2:  2=>
        |4:   Prediction: 2
        |0:   Prediction: 0
        |2:   Prediction: 1
        |1:   Prediction: 1
Criteria : information_gain
Accuracy:  0.9666666666666667
Precision:  1.0
Recall:  0.8888888888888888
Precision:  1.0
Recall:  0.8888888888888888
Precision:  1.0
Recall:  0.8888888888888888
Precision:  1.0
Recall:  0.8888888888888888
Precision:  1.0
Recall:  0.8888888888888888
|:  2=>
    |3:  0=>
        |0:   Prediction: 0
        |3:  1=>
            |0:  3=>
                |1:   Prediction: 0
                |2:   Prediction: 4
            |1:   Prediction: 2
            |4:   Prediction: 1
        |4:   Prediction: 1
        |2:   Prediction: 1
        |1:   Prediction: 2
    |4:  4=>
        |4:  0=>
            |0:   Prediction: 4
            |1:   Prediction: 2
        |1:  0=>
            |3:  1=>
                |0:  3=>
                    |0:   Prediction: 0
            |0:   Prediction: 3
        |2:  0=>
            |4:   Prediction: 4
            |0:   Prediction: 3
        |0:   Prediction: 0
    |1:  3=>
        |1:  0=>
            |0:   Prediction: 4
            |4:   Prediction: 1
        |4:  0=>
            |3:   Prediction: 2
            |4:   Prediction: 1
        |0:   Prediction: 3
    |0:  0=>
        |1:  1=>
            |3:  3=>
                |1:   Prediction: 2
                |4:   Prediction: 3
        |4:   Prediction: 0
    |2:  1=>
        |3:  0=>
            |2:   Prediction: 3
            |3:   Prediction: 0
        |2:   Prediction: 1
Criteria : gini_index
Accuracy:  0.9666666666666667
Precision:  1.0
Recall:  0.8888888888888888
Precision:  1.0
Recall:  0.8888888888888888
Precision:  1.0
Recall:  0.8888888888888888
Precision:  1.0
Recall:  0.8888888888888888
Precision:  1.0
Recall:  0.8888888888888888
|:  4=>
    |0:  0=>
        |3:   Prediction: 1.0062928092144405
        |1:  1=>
            |4:   Prediction: 0.8356921120651418
            |3:   Prediction: 1.2012139221639448
        |0:   Prediction: 1.1677820616598074
        |2:   Prediction: 0.3376026620752022
        |4:   Prediction: -0.48760622407249354
    |2:  0=>
        |4:  1=>
            |0:   Prediction: -0.5768918695231487
            |3:   Prediction: 0.8711247034316923
            |1:   Prediction: -0.32602353216784113
        |1:  1=>
            |3:   Prediction: 0.5298041779152828
            |0:   Prediction: -0.42098448082026296
        |2:   Prediction: -2.4716445001272893
        |3:   Prediction: 0.08658978747289992
    |1:  1=>
        |0:   Prediction: -1.129706854657618
        |1:  0=>
            |4:   Prediction: 1.4415686206579004
            |3:   Prediction: -0.4080753730215514
        |2:   Prediction: 0.37114587337130883
        |3:   Prediction: -0.4325581878196209
        |4:   Prediction: -2.038124535177854
    |4:  3=>
        |3:  0=>
            |2:   Prediction: -0.7968952554704768
            |4:   Prediction: -1.008086310917404
        |1:   Prediction: -0.2030453860429927
        |0:   Prediction: 0.39445214237829684
        |4:   Prediction: 2.075400798645439
    |3:  2=>
        |2:   Prediction: 0.57707212718054
        |4:   Prediction: -0.6039851867158206
        |1:   Prediction: -0.15567723539207948
        |0:  3=>
            |0:   Prediction: 0.2544208433012131
            |2:   Prediction: 0.2897748568964129
        |3:   Prediction: -0.4118769661224674
Criteria : information_gain
RMSE:  0.0
MAE:  0.0
```
