import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from tree.base import DecisionTree
from metrics import *
from sklearn.datasets import make_classification
from sklearn.model_selection import KFold
from sklearn.model_selection import train_test_split
np.random.seed(42)

# Code given in the question
X, y = make_classification(
    n_features=2, n_redundant=0, n_informative=2, random_state=1, n_clusters_per_class=2, class_sep=0.5)

# For plotting
plt.scatter(X[:, 0], X[:, 1], c=y)
# Write the code for Q2 a) and b) below. Show your results.

#Q2 a)
X_train,X_test,y_train,y_test=train_test_split(X,y,test_size=0.3,random_state=None)
X_train=pd.DataFrame(X_train)
y_train=pd.Series(y_train)
X_test=pd.DataFrame(X_test)
y_test=pd.Series(y_test)

dt=DecisionTree("information_gain")
dt.fit(X_train,y_train)
y_pred=dt.predict(X_test)
# Accuracy
print("Accuracy => ",accuracy(y_pred,y_test))

# Per Class Precision and Recall
for cls in y_test.unique():
    print(f"Precision ({cls}): ", precision(y_pred, y_test, cls))
    print(f"Recall ({cls}): ", recall(y_pred, y_test, cls))

#Q2 b)
# Creating Hyperparameter for finding best Depth
hyperparameter={}
hyperparameter['max_depth']=[1,2,3,4,5,6]

# 5 Folds
num_inner_folds=5
num_outer_folds=5

kf_outer=KFold(n_splits=num_outer_folds,shuffle=False)
kf_inner=KFold(n_splits=num_inner_folds,shuffle=False)

outer_loop_accuracies=[]
inner_loop_accuracies=[]
results= {}
outer_count = 0
overall_count = 0


for outer_train_index,outer_test_index in kf_outer.split(X):
  X_outer_train,X_outer_test=X[outer_train_index],X[outer_test_index]
  y_outer_train,y_outer_test=y[outer_train_index],y[outer_test_index]

  inner_count=0
  for inner_train_index,inner_test_index in kf_inner.split(X_outer_train):
    X_inner_train,X_inner_test=X_outer_train[inner_train_index],X_outer_train[inner_test_index]
    y_inner_train,y_inner_test=y_outer_train[inner_train_index],y_outer_train[inner_test_index]
    X_inner_train=pd.DataFrame(X_inner_train)
    X_inner_test=pd.DataFrame(X_inner_test)
    y_inner_train=pd.Series(y_inner_train)
    y_inner_test=pd.Series(y_inner_test)
    print("Outer Fold {}, Inner Fold {}".format(outer_count+1, inner_count+1))

    for max_depth in hyperparameter['max_depth']:
      dt_classifier=DecisionTree("information_gain",max_depth)
      dt_classifier.fit(X_inner_train,y_inner_train)
      y_pred=dt_classifier.predict(X_inner_test)
      val_accuracy=accuracy(y_pred,y_inner_test)

      results[overall_count]={'outer_fold':outer_count,'inner_fold':inner_count,'max_depth':max_depth,'val_accuracy':val_accuracy}
      overall_count+=1
    inner_count+=1
  outer_count+=1

overall_results=pd.DataFrame(results).T
print(overall_results.sort_values(by='val_accuracy',ascending=False))

print(overall_results.groupby(['max_depth']).mean()['val_accuracy'].sort_values(ascending=False))
